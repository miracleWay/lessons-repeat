// Строгий режим
"use strict"
